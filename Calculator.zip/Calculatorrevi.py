from tkinter import *
val = " "
A = 0

def result():
    global A
    global operator
    global val
    val2 = val
    if operator == "+":
        x = int((val2.split("+")[1]))
        C = A + x
        data.set(C)
        val = str(C)
    elif operator == "-" :
        x = int((val2.split("-")[1]))
        C = A - x
        data.set(C)
        val = str(C)
    elif operator == "*" :
        x = int((val2.split("*")[1]))
        C = A * x
        data.set(C)
        val = str(C)
    elif operator == "/":
        x = int((val2.split("/")[1]))
        if x ==0:
            messagebox.showerror("Error","Division by 0 not supported")             # Here Show The Message
            A = ""
            val = ""
            data.set(val)
        else:
            C = int(A/x)
            data.set(C)
            val = str(C)




















def plus_btn_clicked():
    global A
    global operator
    operator = "+"
    global val
    A = int(val)
    val = val + "+"
    data.set(val)

def minus_btn_is_clicked():
    global val
    global operator
    global A
    operator = "-"
    A = int(val)
    val = val + "-"
    data.set(val)

def mul():
    global val
    global A
    global operator
    operator = "*"
    A = int(val)
    val = val + "*"
    data.set(val)

def div():
    global val
    global A
    global operator
    operator = "/"
    A = int(val)
    val = val + "/"
    data.set(val)

def C_btn():
    global val
    global A
    global operator
    operator = ""
    A = 0
    val = ""
    data.set(val)









def btn_1_is_clicked():
    global val
    val = val + "1"
    data.set(val)

def btn_2_is_clicked():
    global val
    val = val + "2"
    data.set(val)

def btn_3_is_clicked():
    global val
    val = val + "3"
    data.set(val)

def btn_4_is_clicked():
    global val
    val = val + "4"
    data.set(val)

def btn_5_is_clicked():
    global val
    val = val + "5"
    data.set(val)

def btn_6_is_clicked():
    global val
    val = val + "6"
    data.set(val)

def btn_7_is_clicked():
    global val
    val = val + "7"
    data.set(val)

def btn_8_is_clicked():
    global val
    val = val + "8"
    data.set(val)

def btn_9_is_clicked():
    global val
    val = val + "9"
    data.set(val)

def btn_0_is_clicked():
    global val
    val = val + "0"
    data.set(val)


root = Tk()
root.geometry("250x400")
root.title('Calculator With Mayur Thorat')

data = StringVar()

lbl = Label(root,text="Label",bg='black',fg="white",anchor=SE,font = ('Verdana',40),textvariable = data)
lbl.pack(expand=True,fill="both")


buttonrow1 = Frame(root,bg="white")
buttonrow1.pack(expand=True,fill="both")

buttonrow2 = Frame(root,bg = "white")
buttonrow2.pack(expand = True,fill="both")

buttonrow3 = Frame(root,bg = "white")
buttonrow3.pack(expand = True,fill="both")

buttonrow4 = Frame(root,bg = "white")
buttonrow4.pack(expand = True,fill="both")

button1 = Button(buttonrow1,text="1",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_1_is_clicked)
button1.pack(side=LEFT,expand=True,fill="both")
button2 = Button(buttonrow1,text="2",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_2_is_clicked)
button2.pack(side=LEFT,expand=True,fill="both")
button3 = Button(buttonrow1,text="3",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_3_is_clicked)
button3.pack(side=LEFT,expand=True,fill="both")
button4 = Button(buttonrow1,text="+",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = plus_btn_clicked)
button4.pack(side=LEFT,expand=True,fill="both")

button1 = Button(buttonrow2,text="4",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_4_is_clicked)
button1.pack(side=LEFT,expand=True,fill="both")
button2 = Button(buttonrow2,text="5",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_5_is_clicked)
button2.pack(side=LEFT,expand=True,fill="both")
button3 = Button(buttonrow2,text="6",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_6_is_clicked)
button3.pack(side=LEFT,expand=True,fill="both")
button4 = Button(buttonrow2,text="-",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = minus_btn_is_clicked)
button4.pack(side=LEFT,expand=True,fill="both")

button1 = Button(buttonrow3,text="7",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_7_is_clicked)
button1.pack(side=LEFT,expand=True,fill="both")
button2 = Button(buttonrow3,text="8",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_8_is_clicked)
button2.pack(side=LEFT,expand=True,fill="both")
button3 = Button(buttonrow3,text="9",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_9_is_clicked)
button3.pack(side=LEFT,expand=True,fill="both")
button4 = Button(buttonrow3,text="*",font = ('Varadana' , 22),bd=0,relief = GROOVE,command =mul)
button4.pack(side=LEFT,expand=True,fill="both")


button1 = Button(buttonrow4,text="0",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = btn_0_is_clicked)
button1.pack(side=LEFT,expand=True,fill="both")
button2 = Button(buttonrow4,text="C",font = ('Varadana' , 22),bd=0,relief = GROOVE,command =C_btn)
button2.pack(side=LEFT,expand=True,fill="both")
button3 = Button(buttonrow4,text="=",font = ('Varadana' , 22),bd=0,relief = GROOVE,command = result)
button3.pack(side=LEFT,expand=True,fill="both")
button4 = Button(buttonrow4,text="/",font = ('Varadana' , 22),bd=0,relief = GROOVE,command =div)
button4.pack(side=LEFT,expand=True,fill="both")


root.mainloop()
